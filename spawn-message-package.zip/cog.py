from __future__ import annotations

import logging
import math
import os
import random
import string
from pathlib import Path
from string import Formatter
from typing import TYPE_CHECKING

import discord
import yaml
from discord import app_commands
from discord.ext import commands

from ballsdex.packages.countryballs.countryball import BallSpawnView
from ballsdex.core.models import balls as countryballs
from ballsdex.settings import settings

if TYPE_CHECKING:
    from ballsdex.core.bot import BallsDexBot
    from ballsdex.core.models import Ball

log = logging.getLogger("spawn_messages_v2")
MAX_MESSAGE_LENGTH = 1900
MAX_TIER_NAME_LENGTH = 48
MAX_BALL_ID = 2147483647
FORMAT_FIELDS = {"ball", "emoji", "collectible", "collectibles", "user"}
DATA_FILE = Path(os.environ.get("BALLSDEX_SPAWN_MESSAGES_FILE", "spawn-message-overrides.yml"))


def normalize_key(value: str) -> str:
    return value.strip().casefold()


def _default_data() -> dict:
    return {"version": 2, "admins": [], "balls": {}, "tiers": {}}


def _read_data() -> dict:
    try:
        data = yaml.safe_load(DATA_FILE.read_text(encoding="utf-8")) or {}
    except FileNotFoundError:
        return _default_data()
    except (OSError, yaml.YAMLError):
        log.exception("Could not read spawn message data from %s", DATA_FILE)
        return _default_data()

    if not isinstance(data, dict):
        return _default_data()
    result = _default_data()
    if isinstance(data.get("admins"), list):
        result["admins"] = data["admins"]
    if isinstance(data.get("tiers"), dict):
        result["tiers"] = data["tiers"]

    if data.get("version") == result["version"] and isinstance(data.get("balls"), dict):
        result["balls"] = {
            str(int(key)): message
            for key, message in data["balls"].items()
            if str(key).isdecimal() and isinstance(message, str)
        }
    if result != data:
        _write_data(result)
    return result


def _write_data(data: dict) -> None:
    DATA_FILE.parent.mkdir(parents=True, exist_ok=True)
    temporary = DATA_FILE.with_suffix(DATA_FILE.suffix + ".tmp")
    temporary.write_text(
        yaml.safe_dump(data, allow_unicode=True, sort_keys=True),
        encoding="utf-8",
    )
    temporary.replace(DATA_FILE)


def _format_message(template: str, ball: Ball, bot: BallsDexBot) -> str:
    emoji = bot.get_emoji(ball.emoji_id)
    values = {
        "ball": ball.country,
        "emoji": str(emoji) if emoji else "",
        "collectible": settings.collectible_name,
        "collectibles": settings.plural_collectible_name,
        "user": "",
    }
    try:
        fields = {field for _, field, _, _ in Formatter().parse(template) if field}
        if not fields.issubset(FORMAT_FIELDS):
            return template
        return template.format_map(values)[:MAX_MESSAGE_LENGTH]
    except (ValueError, KeyError, IndexError):
        return template[:MAX_MESSAGE_LENGTH]


def _select_message(ball: Ball, bot: BallsDexBot) -> str:
    data = _read_data()
    named_message = data["balls"].get(str(ball.pk))
    if isinstance(named_message, str) and named_message:
        return _format_message(named_message, ball, bot)

    matching_tiers = []
    for tier in data["tiers"].values():
        if not isinstance(tier, dict):
            continue
        try:
            maximum = float(tier["max_rarity"])
            if math.isfinite(maximum) and ball.rarity <= maximum:
                matching_tiers.append((maximum, tier.get("message", "")))
        except (KeyError, TypeError, ValueError):
            continue
    if matching_tiers:
        _, template = min(matching_tiers, key=lambda tier: tier[0])
        if isinstance(template, str) and template:
            return _format_message(template, ball, bot)

    template = random.choice(settings.spawn_messages or ["A wild {collectible} appeared!"])
    return _format_message(template, ball, bot)


async def _spawn_with_custom_message(self: BallSpawnView, channel: discord.TextChannel) -> bool:
    def generate_random_name() -> str:
        source = string.ascii_uppercase + string.ascii_lowercase + string.ascii_letters
        return "".join(random.choices(source, k=15))

    extension = self.model.wild_card.split(".")[-1]
    file_location = "./admin_panel/media/" + self.model.wild_card
    file_name = f"nt_{generate_random_name()}.{extension}"
    try:
        permissions = channel.permissions_for(channel.guild.me)
        if permissions.attach_files and permissions.send_messages:
            spawn_message = _select_message(self.model, self.bot)
            self.message = await channel.send(
                spawn_message,
                view=self,
                file=discord.File(file_location, filename=file_name),
                allowed_mentions=discord.AllowedMentions.none(),
            )
            return True
        log.warning("Missing permission to spawn ball in channel %s.", channel)
    except discord.Forbidden:
        log.warning("Missing permission to spawn ball in channel %s.", channel)
    except discord.HTTPException:
        log.error("Failed to spawn ball", exc_info=True)
    return False


class SpawnMessageCog(commands.GroupCog, group_name="spawn-message", group_description="Manage global spawn messages"):
    def __init__(self, bot: BallsDexBot):
        self.bot = bot
        self.data = _read_data()

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if await self.bot.is_owner(interaction.user):
            return True
        if interaction.user.id in self.data["admins"]:
            return True
        await interaction.response.send_message(
            "You are not authorized to change the bot's global spawn messages.", ephemeral=True
        )
        return False

    def save(self) -> None:
        _write_data(self.data)

    @app_commands.command(name="authorize", description="Allow a user to manage global spawn messages")
    @app_commands.describe(user="User to authorize")
    async def authorize(self, interaction: discord.Interaction, user: discord.User) -> None:
        if not await self.bot.is_owner(interaction.user):
            await interaction.response.send_message("Only the bot owner can authorize users.", ephemeral=True)
            return
        if user.id not in self.data["admins"]:
            self.data["admins"].append(user.id)
            self.save()
        await interaction.response.send_message(f"Authorized {user.mention}.", ephemeral=True)

    @app_commands.command(name="unauthorize", description="Remove a user's spawn-message access")
    @app_commands.describe(user="User to unauthorize")
    async def unauthorize(self, interaction: discord.Interaction, user: discord.User) -> None:
        if not await self.bot.is_owner(interaction.user):
            await interaction.response.send_message("Only the bot owner can unauthorize users.", ephemeral=True)
            return
        self.data["admins"] = [user_id for user_id in self.data["admins"] if user_id != user.id]
        self.save()
        await interaction.response.send_message(f"Removed spawn-message access for {user.mention}.", ephemeral=True)

    @app_commands.command(name="ball-set", description="Set a message for one countryball ID")
    @app_commands.describe(ball_id="Internal countryball database ID", message="Spawn message")
    async def ball_set(
        self,
        interaction: discord.Interaction,
        ball_id: app_commands.Range[int, 1, MAX_BALL_ID],
        message: app_commands.Range[str, 1, MAX_MESSAGE_LENGTH],
    ) -> None:
        ball = countryballs.get(ball_id)
        if ball is None:
            await interaction.response.send_message(
                f"No countryball is registered with ID `{ball_id}`.", ephemeral=True
            )
            return
        self.data["balls"][str(ball_id)] = message
        self.save()
        await interaction.response.send_message(
            f"Saved the spawn message for **{ball.country}** (ID `{ball_id}`).", ephemeral=True
        )

    @app_commands.command(name="ball-remove", description="Remove a countryball-specific message")
    @app_commands.describe(ball_id="Internal countryball database ID")
    async def ball_remove(
        self,
        interaction: discord.Interaction,
        ball_id: app_commands.Range[int, 1, MAX_BALL_ID],
    ) -> None:
        removed = self.data["balls"].pop(str(ball_id), None) is not None
        self.save()
        response = "Removed the countryball override." if removed else "No override was set for that ID."
        await interaction.response.send_message(response, ephemeral=True)

    @app_commands.command(name="ball-list", description="List countryball-specific messages")
    @app_commands.describe(page="Page number")
    async def ball_list(
        self,
        interaction: discord.Interaction,
        page: app_commands.Range[int, 1, 10000] = 1,
    ) -> None:
        entries = sorted(
            self.data["balls"].items(),
            key=lambda item: (
                not str(item[0]).isdecimal(),
                int(item[0]) if str(item[0]).isdecimal() else str(item[0]),
            ),
        )
        await self._send_page(interaction, entries, page, "Countryball overrides")

    @app_commands.command(name="tier-set", description="Set a message for a rarity tier")
    @app_commands.describe(
        tier="Tier label, such as rare or legendary",
        max_rarity="Matches balls at or below this numeric rarity",
        message="Spawn message",
    )
    async def tier_set(
        self,
        interaction: discord.Interaction,
        tier: app_commands.Range[str, 1, MAX_TIER_NAME_LENGTH],
        max_rarity: app_commands.Range[float, 0.0, 1000000000.0],
        message: app_commands.Range[str, 1, MAX_MESSAGE_LENGTH],
    ) -> None:
        tier_name = tier.strip()
        if not tier_name or not math.isfinite(max_rarity):
            await interaction.response.send_message("Enter a valid tier and rarity threshold.", ephemeral=True)
            return
        key = normalize_key(tier_name)
        self.data["tiers"][key] = {"name": tier_name, "max_rarity": max_rarity, "message": message}
        self.save()
        await interaction.response.send_message(
            f"Saved **{tier_name}** for rarity values up to `{max_rarity}`.", ephemeral=True
        )

    @app_commands.command(name="tier-remove", description="Remove a rarity-tier message")
    @app_commands.describe(tier="Tier label")
    async def tier_remove(
        self,
        interaction: discord.Interaction,
        tier: app_commands.Range[str, 1, MAX_TIER_NAME_LENGTH],
    ) -> None:
        removed = self.data["tiers"].pop(normalize_key(tier), None) is not None
        self.save()
        response = "Removed the rarity tier." if removed else "No tier was set with that label."
        await interaction.response.send_message(response, ephemeral=True)

    @app_commands.command(name="tier-list", description="List rarity-tier messages")
    @app_commands.describe(page="Page number")
    async def tier_list(
        self,
        interaction: discord.Interaction,
        page: app_commands.Range[int, 1, 10000] = 1,
    ) -> None:
        entries = sorted(
            self.data["tiers"].items(),
            key=lambda item: float(item[1].get("max_rarity", math.inf)),
        )
        await self._send_page(interaction, entries, page, "Rarity tiers")

    async def _send_page(self, interaction, entries, page: int, title: str) -> None:
        page_size = 8
        page_count = max(1, (len(entries) + page_size - 1) // page_size)
        if page > page_count:
            await interaction.response.send_message(f"There are only {page_count} pages.", ephemeral=True)
            return
        page_entries = entries[(page - 1) * page_size : page * page_size]
        if not page_entries:
            text = "No custom messages configured."
        elif title == "Countryball overrides":
            lines = []
            for ball_id, message in page_entries:
                ball = countryballs.get(int(ball_id)) if str(ball_id).isdecimal() else None
                label = f"**{ball.country}** (ID `{ball_id}`)" if ball else f"ID `{ball_id}`"
                lines.append(f"{label}: {message.replace(chr(10), ' ')[:60]}")
            text = "\n".join(lines)
        else:
            text = "\n".join(
                f"**{tier['name']}** (rarity <= `{tier['max_rarity']}`): "
                f"{tier['message'].replace(chr(10), ' ')[:60]}"
                for _, tier in page_entries
            )
        await interaction.response.send_message(
            f"{title}, page {page}/{page_count}\n{text}",
            ephemeral=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )


async def setup(bot: BallsDexBot) -> None:
    await bot.add_cog(SpawnMessageCog(bot))
    BallSpawnView.spawn = _spawn_with_custom_message