# BallsDex 2.30.0 spawn messages

This repository contains the 2.30.0-compatible extension only. See [`spawn_messages_v2/README.md`](spawn_messages_v2/README.md) for installation, commands, and persistent storage setup.