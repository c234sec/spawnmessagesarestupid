# BallsDex 2.30.0 spawn messages

This is the legacy extension for BallsDex 2.30.0. It is a separate implementation from the 3.x package in this repository.

## Install

Install this repository into the BallsDex 2.30.0 Python environment so `spawn_messages_v2` is importable. In the bot's `config.yml`, append the package root to `packages`, after `ballsdex.packages.countryballs`:

```yaml
packages:
  - ballsdex.packages.admin
  - ballsdex.packages.balls
  - ballsdex.packages.config
  - ballsdex.packages.countryballs
  - ballsdex.packages.info
  - ballsdex.packages.players
  - ballsdex.packages.trade
  - spawn_messages_v2
```

If the team copies the module directory directly into the bot source at `ballsdex/packages/spawn_messages_v2`, use `ballsdex.packages.spawn_messages_v2` in `config.yml` instead. The package root delegates to the cog setup in either case, which installs the 2.30 spawn override. This is a 2.30-specific integration point and should be retested if the bot is upgraded.

## Persistent data

By default, the bot reads and writes `spawn-message-overrides.yml` relative to its working directory. Set `BALLSDEX_SPAWN_MESSAGES_FILE` to a path on persistent storage if the host's bot directory is not persistent. The bot process must have permission to create and replace that file.

## Commands

- `/spawn-message authorize user` and `/spawn-message unauthorize user`: bot-owner-only access management
- `/spawn-message ball-set ball_id:<ID>` and `/spawn-message ball-remove ball_id:<ID>`: internal-ID overrides
- `/spawn-message ball-list`: paginated overrides
- `/spawn-message tier-set`, `/spawn-message tier-remove`, and `/spawn-message tier-list`: rarity-tier messages

Rules are global to this bot instance. Exact ID overrides take priority over tiers; among matching tiers, the smallest maximum rarity is used. Since low BallsDex rarity values spawn less often, use lower thresholds for rarer tiers. If nothing matches, the existing `catch.spawn_msgs` prompt pool from `config.yml` remains the fallback.

Use the `id` shown for a countryball in the Ballsdex admin panel when setting or removing an override. On first load of the ID-based sidecar format, old name-keyed ball overrides are discarded; rarity tiers and authorized managers remain.

Templates support `{ball}`, `{emoji}`, `{collectible}`, and `{collectibles}`. `{user}` expands to an empty string for spawn messages. Messages are limited to 1900 characters and mentions are disabled when sent.

The bot owner must run `/spawn-message authorize user:<your Discord account>` once before you can manage the global messages.