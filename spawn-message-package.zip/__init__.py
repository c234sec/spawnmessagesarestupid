"""BallsDex 2.30 spawn message customization."""

from .cog import setup